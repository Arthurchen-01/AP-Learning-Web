// background/service-worker.js
// AP Exam Capture - Background Service Worker (MVP)
// 负责：网络拦截调度 + 下载管理 + 跨页面协调

// ==================== 全局状态 ====================
let sessionId = null;
let captureActive = false;
let eventLog = [];
let networkLog = [];
let storageSnapshot = null;
let injectedStateSnapshot = null;

// ==================== 初始化 ====================
function initSession() {
  sessionId = `ap-capture-${Date.now()}`;
  eventLog = [];
  networkLog = [];
  storageSnapshot = null;
  injectedStateSnapshot = null;
  console.log(`[AP-Capture] Session started: ${sessionId}`);
}

initSession();

// ==================== 来自 Content Script 的消息 ====================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { type, payload } = message;

  switch (type) {
    case 'NETWORK_REQUEST':
      handleNetworkRequest(payload);
      break;
    case 'NETWORK_RESPONSE':
      handleNetworkResponse(payload);
      break;
    case 'STORAGE_SNAPSHOT':
      handleStorageSnapshot(payload);
      break;
    case 'INJECTED_STATE':
      handleInjectedState(payload);
      break;
    case 'PAGE_EVENT':
      handlePageEvent(payload);
      break;
    case 'START_CAPTURE':
      startCapture();
      break;
    case 'STOP_CAPTURE':
      stopCapture();
      break;
    case 'EXPORT_SESSION':
      exportSession();
      break;
    case 'GET_STATUS':
      sendResponse({ sessionId, captureActive, eventCount: eventLog.length, networkCount: networkLog.length });
      break;
    case 'TOOLBAR_CONFIG':
      handleToolbarConfig(payload);
      break;
    case 'DOM_STYLES':
      handleDomStyles(payload);
      break;
    case 'MATH_ELEMENTS':
      handleMathElements(payload);
      break;
    case 'DOM_SNAPSHOT':
      handleDomSnapshot(payload);
      break;
    default:
      console.warn(`[AP-Capture] Unknown message type: ${type}`);
  }
});

// ==================== 网络请求记录 ====================
function handleNetworkRequest(payload) {
  if (!captureActive) return;

  const entry = {
    type: 'request',
    id: generateId(),
    timestamp: new Date().toISOString(),
    url: payload.url,
    method: payload.method || 'GET',
    headers: payload.headers || {},
    body: payload.body || null,
    tabId: payload.tabId
  };

  networkLog.push(entry);
  console.log(`[AP-Capture] ↗ ${entry.method} ${entry.url}`);
}

function handleNetworkResponse(payload) {
  if (!captureActive) return;

  // 找到对应的请求，补充 response 信息
  const matched = networkLog.find(e => e.id === payload.requestId);
  if (matched) {
    matched.status = payload.status;
    matched.responseHeaders = payload.headers || {};
    matched.responseBody = payload.body || null;
    matched.responseTimestamp = new Date().toISOString();
  }

  console.log(`[AP-Capture] ↙ ${payload.status} ${payload.url}`);
}

// ==================== 存储快照 ====================
function handleStorageSnapshot(payload) {
  if (!captureActive) return;

  storageSnapshot = {
    timestamp: new Date().toISOString(),
    localStorage: payload.localStorage || {},
    sessionStorage: payload.sessionStorage || {},
    indexedDB: payload.indexedDB || null,
    url: payload.url
  };

  console.log('[AP-Capture] 💾 Storage snapshot captured');
}

// ==================== 注水状态 ====================
function handleInjectedState(payload) {
  if (!captureActive) return;

  injectedStateSnapshot = {
    timestamp: new Date().toISOString(),
    nextData: payload.nextData || null,
    initialState: payload.initialState || null,
    nuxt: payload.nuxt || null,
    vuex: payload.vuex || null,
    url: payload.url
  };

  console.log('[AP-Capture] 🌀 Injected state captured');
}

// ==================== 页面事件 ====================
function handlePageEvent(payload) {
  if (!captureActive) return;

  const event = {
    id: generateId(),
    timestamp: new Date().toISOString(),
    eventType: payload.eventType,
    url: payload.url,
    questionNumber: payload.questionNumber || null,
    section: payload.section || null,
    part: payload.part || null,
    details: payload.details || {},
    storageSnapshot: storageSnapshot ? { ...storageSnapshot } : null,
    injectedState: injectedStateSnapshot ? { ...injectedStateSnapshot } : null,
    // 附带最近的网络请求（前后各5条）
    recentNetwork: getRecentNetwork()
  };

  eventLog.push(event);
  console.log(`[AP-Capture] 🎯 Event: ${event.eventType} at ${event.url}`);

  // 每次事件都触发一次增量下载（轻量化）
  downloadEventFile(event);
}

// ==================== 工具栏配置 ====================
function handleToolbarConfig(payload) {
  if (!captureActive) return;
  
  console.log('[AP-Capture] 🛠️ Toolbar config:', payload.visibleTools);
  
  // 保存到 storage，供后续使用
  if (!eventLog.length) {
    eventLog.push({ toolbar: payload });
  } else {
    eventLog[eventLog.length - 1].toolbar = payload;
  }
}

// ==================== DOM 样式 ====================
function handleDomStyles(payload) {
  if (!captureActive) return;
  
  console.log('[AP-Capture] 🎨 DOM styles captured');
  
  if (eventLog.length) {
    eventLog[eventLog.length - 1].domStyles = payload;
  }
}

// ==================== MathML 元素 ====================
function handleMathElements(payload) {
  if (!captureActive) return;
  
  console.log(`[AP-Capture] 🔢 Math elements: ${payload.mathElements.length}`);
  
  if (eventLog.length) {
    eventLog[eventLog.length - 1].mathElements = payload;
  }
}

// ==================== DOM 快照 ====================
function handleDomSnapshot(payload) {
  if (!captureActive) return;
  
  console.log('[AP-Capture] 📸 DOM snapshot captured');
  
  if (eventLog.length) {
    eventLog[eventLog.length - 1].domSnapshot = payload;
  }
}

// ==================== 工具函数 ====================
function generateId() {
  return Math.random().toString(36).substring(2, 10);
}

function getRecentNetwork() {
  const recent = networkLog.slice(-10);
  // 脱敏处理：移除敏感 headers
  return recent.map(e => ({
    id: e.id,
    timestamp: e.timestamp,
    method: e.method,
    url: maskUrl(e.url),
    status: e.status,
    bodySize: e.responseBody ? JSON.stringify(e.responseBody).length : 0
  }));
}

function maskUrl(url) {
  try {
    const u = new URL(url);
    // 保留 host + pathname，移除 query 参数中的敏感信息
    const params = new URLSearchParams(u.search);
    const masked = [];
    for (const [key, value] of params) {
      if (['token', 'key', 'secret', 'auth', 'password'].some(k => key.toLowerCase().includes(k))) {
        masked.push(`${key}=[REDACTED]`);
      } else {
        masked.push(`${key}=${value}`);
      }
    }
    u.search = masked.join('&');
    return u.toString();
  } catch {
    return url;
  }
}

// ==================== 采集控制 ====================
function startCapture() {
  captureActive = true;
  initSession();
  console.log('[AP-Capture] 🚀 Capture started');
  saveManifest();
}

function stopCapture() {
  captureActive = false;
  console.log('[AP-Capture] ⏹️ Capture stopped');
  exportSession();
}

// ==================== 文件下载 ====================
async function downloadEventFile(event) {
  const content = JSON.stringify(event, null, 2);
  const blob = new Blob([content], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  try {
    await chrome.downloads.download({
      url: url,
      filename: `${sessionId}/events/event-${event.id}.json`,
      saveAs: false
    });
    console.log(`[AP-Capture] 📥 Event file saved: event-${event.id}.json`);
  } catch (err) {
    console.error('[AP-Capture] Download error:', err);
  }
}

  // 保存 manifest 时自动用 saveAs 让用户选择位置
async function saveManifest() {
  const manifest = {
    sessionId: sessionId,
    startedAt: new Date().toISOString(),
    version: '1.0.0',
    description: 'AP Exam Capture Session',
    targetUrl: 'https://mokaoai.com/en/ap/',
    captureSettings: {
      networkLogging: true,
      storageCapture: true,
      storageDiff: true,
      indexedDBCapture: true,
      injectedStateCapture: true,
      eventCapture: true,
      toolbarCapture: true,
      domStylesCapture: true,
      mathCapture: true
    },
    eventIndex: eventLog.map(e => ({
      id: e.id,
      timestamp: e.timestamp,
      eventType: e.eventType,
      questionNumber: e.questionNumber,
      url: e.url
    })),
    networkIndex: networkLog.slice(0, 100).map(n => ({
      id: n.id,
      timestamp: n.timestamp,
      method: n.method,
      url: maskUrl(n.url),
      status: n.status
    }))
  };

  const content = JSON.stringify(manifest, null, 2);
  const blob = new Blob([content], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  try {
    const downloadId = await chrome.downloads.download({
      url: url,
      filename: `${sessionId}/session-manifest.json`,
      saveAs: false  // 让用户选择保存位置
    });
    console.log('[AP-Capture] 📋 Manifest saved, downloadId:', downloadId);
  } catch (err) {
    console.error('[AP-Capture] Manifest download error:', err);
  }
}

async function exportSession() {
  console.log('[AP-Capture] Export called, events:', eventLog.length, 'network:', networkLog.length);
  
  // 如果没有数据，也导出空文件
  if (eventLog.length === 0 && networkLog.length === 0) {
    console.log('[AP-Capture] No data captured, exporting empty session');
  }
  
  // 创建 HTML 索引页面
  const htmlIndex = generateHtmlIndex();
  
  const sessionData = {
    sessionId: sessionId || `ap-capture-${Date.now()}`,
    exportedAt: new Date().toISOString(),
    summary: {
      totalEvents: eventLog.length,
      totalNetworkEntries: networkLog.length,
      captureActive: captureActive
    },
    manifest: {
      sessionId: sessionId || `ap-capture-${Date.now()}`,
      startedAt: new Date().toISOString(),
      version: '1.0.0'
    },
    timeline: eventLog.map(e => ({
      id: e.id,
      timestamp: e.timestamp,
      eventType: e.eventType,
      questionNumber: e.questionNumber,
      section: e.section,
      part: e.part,
      url: e.url,
      hasStorage: !!e.storageSnapshot,
      hasInjectedState: !!e.injectedState,
      hasToolbar: !!e.toolbar,
      hasDomStyles: !!e.domStyles,
      hasMath: !!e.mathElements
    })),
    events: eventLog,
    network: networkLog.slice(0, 500)
  };

  const content = JSON.stringify(sessionData, null, 2);
  const blob = new Blob([content], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const indexBlob = new Blob([htmlIndex], { type: 'text/html' });
  const indexUrl = URL.createObjectURL(indexBlob);

  try {
    // 下载 session-export.json - 让用户选择位置
    const downloadId = await chrome.downloads.download({
      url: url,
      filename: `${sessionId}/session-export.json`,
      saveAs: false
    });
    
    // 下载 HTML 索引页面
    await chrome.downloads.download({
      url: indexUrl,
      filename: `${sessionId}/index.html`,
      saveAs: false  // 第二个文件不弹窗
    });
    
    console.log('[AP-Capture] 📦 Session exported, downloadId:', downloadId);
  } catch (err) {
    console.error('[AP-Capture] Export error:', err);
  }
}

// 生成 HTML 索引页面
function generateHtmlIndex() {
  const eventList = eventLog.slice(0, 50).map(e => `
    <tr>
      <td>${e.timestamp}</td>
      <td>${e.eventType}</td>
      <td>${e.questionNumber || '-'}</td>
      <td>${e.url.substring(0, 50)}...</td>
    </tr>
  `).join('');

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>AP Exam Capture - ${sessionId}</title>
  <style>
    body { font-family: -apple-system, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; }
    h1 { color: #333; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background: #f5f5f5; }
    .summary { background: #f0f0f0; padding: 15px; border-radius: 8px; margin: 20px 0; }
    .files { margin-top: 20px; }
    .file { padding: 8px; border-bottom: 1px solid #eee; }
  </style>
</head>
<body>
  <h1>📸 AP Exam Capture - Session ${sessionId}</h1>
  
  <div class="summary">
    <h2>采集摘要</h2>
    <p>总事件数: ${eventLog.length}</p>
    <p>网络请求数: ${networkLog.length}</p>
    <p>采集时间: ${new Date().toISOString()}</p>
  </div>

  <h2>事件时间线</h2>
  <table>
    <tr>
      <th>时间</th>
      <th>事件类型</th>
      <th>题号</th>
      <th>URL</th>
    </tr>
    ${eventList}
  </table>

  <div class="files">
    <h2>文件列表</h2>
    <div class="file">session-export.json - 完整导出（含所有事件和网络请求）</div>
    <div class="file">session-manifest.json - 会话清单</div>
    <div class="file">index.html - 本索引页面</div>
  </div>
</body>
</html>`;
}

console.log('[AP-Capture] Service Worker loaded');
