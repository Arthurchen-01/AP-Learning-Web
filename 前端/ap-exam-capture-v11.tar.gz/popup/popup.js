// popup.js - AP Exam Capture 弹窗逻辑

document.addEventListener('DOMContentLoaded', async () => {
  const statusEl = document.getElementById('status');
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const exportBtn = document.getElementById('exportBtn');
  const infoEl = document.getElementById('info');

  // 目标网站 - 更宽松的匹配
  const targetPatterns = [
    /mokaoai\.com/i,
    /examId=/i,
    /\/ap\//i,
    /mokao/i
  ];

  // 获取当前 tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!tab || !tab.url) {
    statusEl.textContent = '无法获取页面信息';
    return;
  }

  // 显示当前 URL 供调试
  console.log('Current URL:', tab.url);
  
  // 检查是否在目标网站
  const isTarget = targetPatterns.some(p => p.test(tab.url));
  
  if (!isTarget) {
    // 不在目标网站，显示警告
    statusEl.textContent = '⚠️ 当前不是目标网站';
    statusEl.className = 'status inactive';
    statusEl.style.background = '#fff3cd';
    statusEl.style.color = '#856404';
    infoEl.textContent = `当前: ${tab.url.substring(0, 40)}`;
    startBtn.disabled = true;
    
    // 设置警告 badge
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#ffc107' });
    return;
  }
  
  // 在目标网站，清除警告
  chrome.action.setBadgeText({ text: '' });

  // 初始状态 - 导出按钮禁用
  startBtn.disabled = false;
  stopBtn.disabled = true;
  exportBtn.disabled = true;
  statusEl.textContent = '✅ 已连接目标页面';
  statusEl.className = 'status active';
  statusEl.style.background = '#d4edda';
  statusEl.style.color = '#155724';
  infoEl.textContent = `当前: ${tab.url.substring(0, 35)}...`;
  
  // 清除所有 badge
  chrome.action.setBadgeText({ text: '' });

  // 获取当前采集状态
  try {
    const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_STATUS' });
    if (response?.captureActive) {
      startBtn.disabled = true;
      stopBtn.disabled = false;
      exportBtn.disabled = true;
      statusEl.textContent = '🔴 采集中...';
      statusEl.style.background = '#f8d7da';
      statusEl.style.color = '#721c24';
      chrome.action.setBadgeText({ text: '●' });
      chrome.action.setBadgeBackgroundColor({ color: '#dc3545' });
    } else {
      // 未采集，导出禁用
      startBtn.disabled = false;
      stopBtn.disabled = true;
      exportBtn.disabled = true;
    }
  } catch (e) {
    // 内容脚本可能还没加载，保持初始状态
    startBtn.disabled = false;
    stopBtn.disabled = true;
    exportBtn.disabled = true;
  }

  // 开始采集
  startBtn.addEventListener('click', async () => {
    try {
      // 先尝试直接发消息给 content script
      try {
        await chrome.tabs.sendMessage(tab.id, { type: 'START_CAPTURE' });
        startBtn.disabled = true;
        stopBtn.disabled = false;
        statusEl.textContent = '🔴 采集中...';
        statusEl.style.background = '#f8d7da';
        statusEl.style.color = '#721c24';
        infoEl.textContent = '开始记录操作...';
        // 设置采集中 badge
        chrome.action.setBadgeText({ text: '●' });
        chrome.action.setBadgeBackgroundColor({ color: '#dc3545' });
        return;
      } catch (e) {
        console.log('Content script not available, trying background');
      }
      
      // 如果 content script 不可用，尝试 background
      await chrome.runtime.sendMessage({ type: 'START_CAPTURE' });
      startBtn.disabled = true;
      stopBtn.disabled = false;
      statusEl.textContent = '🔴 采集中...';
      statusEl.style.background = '#f8d7da';
      statusEl.style.color = '#721c24';
      infoEl.textContent = '开始记录操作...';
      chrome.action.setBadgeText({ text: '●' });
      chrome.action.setBadgeBackgroundColor({ color: '#dc3545' });
    } catch (e) {
      console.error('Start capture error:', e);
      statusEl.textContent = '❌ 启动失败';
      infoEl.textContent = e.message;
    }
  });

  // 停止采集
  stopBtn.addEventListener('click', async () => {
    try {
      await chrome.tabs.sendMessage(tab.id, { type: 'STOP_CAPTURE' });
      // 更新按钮状态
      startBtn.disabled = false;
      stopBtn.disabled = true;
      exportBtn.disabled = false;
      statusEl.textContent = '✅ 已停止';
      statusEl.style.background = '#d4edda';
      statusEl.style.color = '#155724';
      infoEl.textContent = '可以导出数据了';
      chrome.action.setBadgeText({ text: '✓' });
      chrome.action.setBadgeBackgroundColor({ color: '#28a745' });
      
      // 延迟后刷新状态
      setTimeout(async () => {
        try {
          const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_STATUS' });
          if (!response?.captureActive) {
            statusEl.textContent = '✅ 已停止';
            infoEl.textContent = '可以导出数据了';
          }
        } catch (e) {}
      }, 500);
    } catch (e) {
      try {
        await chrome.runtime.sendMessage({ type: 'STOP_CAPTURE' });
        startBtn.disabled = false;
        stopBtn.disabled = true;
        exportBtn.disabled = false;
        statusEl.textContent = '✅ 已停止';
        statusEl.style.background = '#d4edda';
        statusEl.style.color = '#155724';
        infoEl.textContent = '可以导出数据了';
        chrome.action.setBadgeText({ text: '✓' });
        chrome.action.setBadgeBackgroundColor({ color: '#28a745' });
      } catch (e2) {
        statusEl.textContent = '❌ 停止失败';
      }
    }
  });

  // 导出数据
  exportBtn.addEventListener('click', async () => {
    infoEl.textContent = '正在导出...';
    try {
      // 先尝试 background
      await chrome.runtime.sendMessage({ type: 'EXPORT_SESSION' });
      statusEl.textContent = '📦 导出完成！';
      statusEl.style.background = '#d4edda';
      statusEl.style.color = '#155724';
      infoEl.textContent = '请查看下载的文件';
    } catch (e) {
      console.error('Export error:', e);
      statusEl.textContent = '❌ 导出失败: ' + e.message;
      infoEl.textContent = '请重试';
    }
  });
});